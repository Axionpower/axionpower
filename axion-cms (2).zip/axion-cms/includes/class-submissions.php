<?php
/**
 * Axion CMS – Form Submissions
 * REST endpoint to receive submissions + WP admin page to view them.
 * Supports soft-delete (Trash) → permanent delete workflow.
 */

if (!defined('ABSPATH'))
    exit;

class Axion_Submissions
{
    private static $table_name;

    public static function init()
    {
        global $wpdb;
        self::$table_name = $wpdb->prefix . 'axion_submissions';

        add_action('admin_init', [__CLASS__, 'create_table']);
        add_action('rest_api_init', [__CLASS__, 'register_routes']);
        add_action('admin_menu', [__CLASS__, 'register_menu']);
        add_action('admin_init', [__CLASS__, 'handle_actions']);
    }

    // ─── Create / migrate custom table ───
    public static function create_table()
    {
        global $wpdb;
        $table   = self::$table_name;
        $charset = $wpdb->get_charset_collate();

        // Create table if it doesn't exist
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
            $sql = "CREATE TABLE $table (
                id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                form_type VARCHAR(100) NOT NULL DEFAULT '',
                fields LONGTEXT NOT NULL,
                submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                is_read TINYINT(1) NOT NULL DEFAULT 0,
                is_trashed TINYINT(1) NOT NULL DEFAULT 0,
                trashed_at DATETIME DEFAULT NULL,
                ip_address VARCHAR(45) DEFAULT '',
                PRIMARY KEY (id),
                KEY form_type (form_type),
                KEY submitted_at (submitted_at),
                KEY is_trashed (is_trashed)
            ) $charset;";

            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta($sql);
            return;
        }

        // Migration: add is_trashed / trashed_at columns to existing table
        $columns = $wpdb->get_col("SHOW COLUMNS FROM $table LIKE 'is_trashed'");
        if (empty($columns)) {
            $wpdb->query("ALTER TABLE $table ADD COLUMN is_trashed TINYINT(1) NOT NULL DEFAULT 0 AFTER is_read");
            $wpdb->query("ALTER TABLE $table ADD COLUMN trashed_at DATETIME DEFAULT NULL AFTER is_trashed");
            $wpdb->query("ALTER TABLE $table ADD KEY is_trashed (is_trashed)");
        }
    }

    // ─── REST API routes ───
    public static function register_routes()
    {
        register_rest_route('axion/v1', '/contact-form', [
            'methods'             => 'POST',
            'callback'            => [__CLASS__, 'handle_submission'],
            'permission_callback' => '__return_true',
        ]);
    }

    // ─── Handle incoming form submission ───
    public static function handle_submission($request)
    {
        global $wpdb;

        // Rate limiting: max 5 submissions per IP per hour
        $ip       = sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? 'unknown');
        $rate_key = 'axion_rate_' . md5($ip);
        $count    = (int) get_transient($rate_key);

        if ($count >= 5) {
            return new \WP_REST_Response(['error' => 'Too many submissions. Please try again later.'], 429);
        }
        set_transient($rate_key, $count + 1, HOUR_IN_SECONDS);

        $params    = $request->get_json_params();
        $form_type = sanitize_text_field($params['form_type'] ?? 'Unknown');
        $fields    = $params['fields'] ?? [];

        $sanitized = [];
        foreach ($fields as $key => $value) {
            $sanitized[sanitize_text_field($key)] = sanitize_textarea_field($value);
        }

        if (empty($sanitized)) {
            return new \WP_REST_Response(['error' => 'No form data provided'], 400);
        }

        $wpdb->insert(
            self::$table_name,
            [
                'form_type'   => $form_type,
                'fields'      => wp_json_encode($sanitized),
                'submitted_at'=> current_time('mysql'),
                'is_read'     => 0,
                'is_trashed'  => 0,
                'ip_address'  => sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? ''),
            ],
            ['%s', '%s', '%s', '%d', '%d', '%s']
        );

        if ($wpdb->last_error) {
            return new \WP_REST_Response(['error' => 'Database error'], 500);
        }

        // Email notification
        $admin_email   = get_option('admin_email');
        $safe_type     = str_replace(["\r", "\n"], ' ', $form_type);
        $subject       = "New {$safe_type} Submission – Axion";
        $body          = "A new form submission has been received.\n\nForm Type: {$safe_type}\nSubmitted: " . current_time('mysql') . "\n\n";
        foreach ($sanitized as $key => $value) {
            $body .= ucfirst(str_replace(['_', '-'], ' ', str_replace(["\r", "\n"], ' ', $key))) . ': ' . str_replace(["\r", "\n"], ' ', $value) . "\n";
        }
        wp_mail($admin_email, $subject, $body, ['Content-Type: text/plain; charset=UTF-8']);

        return new \WP_REST_Response(['success' => true, 'message' => 'Submission received'], 200);
    }

    // ─── Admin menu ───
    public static function register_menu()
    {
        $unread = self::get_unread_count();
        $badge  = $unread > 0 ? " <span class='update-plugins count-{$unread}'><span class='plugin-count'>{$unread}</span></span>" : '';

        add_submenu_page(
            'axion-cms',
            'Form Submissions',
            'Submissions' . $badge,
            'manage_options',
            'axion-submissions',
            [__CLASS__, 'render_page']
        );
    }

    private static function get_unread_count()
    {
        global $wpdb;
        return (int) $wpdb->get_var("SELECT COUNT(*) FROM " . self::$table_name . " WHERE is_read = 0 AND is_trashed = 0");
    }

    // ─── Handle all admin actions ───
    public static function handle_actions()
    {
        if (!current_user_can('manage_options')) return;

        $table = self::$table_name;

        // ── Trash single ──
        if (isset($_GET['axion_trash_submission'], $_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'axion_trash_submission')) {
                global $wpdb;
                $id = absint($_GET['axion_trash_submission']);
                $wpdb->update($table, ['is_trashed' => 1, 'trashed_at' => current_time('mysql')], ['id' => $id], ['%d', '%s'], ['%d']);
                wp_redirect(admin_url('admin.php?page=axion-submissions&trashed=1'));
                exit;
            }
        }

        // ── Restore single ──
        if (isset($_GET['axion_restore_submission'], $_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'axion_restore_submission')) {
                global $wpdb;
                $id = absint($_GET['axion_restore_submission']);
                $wpdb->update($table, ['is_trashed' => 0, 'trashed_at' => null], ['id' => $id], ['%d', '%s'], ['%d']);
                wp_redirect(admin_url('admin.php?page=axion-submissions&view=trash&restored=1'));
                exit;
            }
        }

        // ── Permanently delete single ──
        if (isset($_GET['axion_delete_submission'], $_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'axion_delete_submission')) {
                global $wpdb;
                $id = absint($_GET['axion_delete_submission']);
                $wpdb->delete($table, ['id' => $id], ['%d']);
                wp_redirect(admin_url('admin.php?page=axion-submissions&view=trash&deleted=1'));
                exit;
            }
        }

        // ── Empty trash ──
        if (isset($_GET['axion_empty_trash'], $_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'axion_empty_trash')) {
                global $wpdb;
                $wpdb->query("DELETE FROM $table WHERE is_trashed = 1");
                wp_redirect(admin_url('admin.php?page=axion-submissions&view=trash&emptied=1'));
                exit;
            }
        }

        // ── Bulk actions ──
        if (isset($_POST['axion_bulk_action'], $_POST['_wpnonce'])) {
            if (wp_verify_nonce($_POST['_wpnonce'], 'axion_bulk_submissions')) {
                global $wpdb;
                $ids    = array_map('absint', $_POST['submission_ids'] ?? []);
                $action = sanitize_text_field($_POST['axion_bulk_action']);

                if (!empty($ids)) {
                    $placeholders = implode(',', array_fill(0, count($ids), '%d'));

                    if ($action === 'trash') {
                        $wpdb->query($wpdb->prepare(
                            "UPDATE $table SET is_trashed = 1, trashed_at = %s WHERE id IN ($placeholders)",
                            array_merge([current_time('mysql')], $ids)
                        ));
                        wp_redirect(admin_url('admin.php?page=axion-submissions&trashed=' . count($ids)));
                        exit;
                    }

                    if ($action === 'restore') {
                        $wpdb->query($wpdb->prepare(
                            "UPDATE $table SET is_trashed = 0, trashed_at = NULL WHERE id IN ($placeholders)",
                            ...$ids
                        ));
                        wp_redirect(admin_url('admin.php?page=axion-submissions&view=trash&restored=' . count($ids)));
                        exit;
                    }

                    if ($action === 'delete') {
                        $wpdb->query($wpdb->prepare(
                            "DELETE FROM $table WHERE id IN ($placeholders)",
                            ...$ids
                        ));
                        wp_redirect(admin_url('admin.php?page=axion-submissions&view=trash&deleted=' . count($ids)));
                        exit;
                    }
                }
            }
        }

        // ── Mark as read ──
        if (isset($_GET['axion_mark_read'], $_GET['_wpnonce'])) {
            if (wp_verify_nonce($_GET['_wpnonce'], 'axion_mark_read')) {
                global $wpdb;
                $id = absint($_GET['axion_mark_read']);
                $wpdb->update($table, ['is_read' => 1], ['id' => $id], ['%d'], ['%d']);
                wp_redirect(admin_url('admin.php?page=axion-submissions'));
                exit;
            }
        }
    }

    // ─── Render admin page ───
    public static function render_page()
    {
        global $wpdb;
        $table = self::$table_name;

        // Single submission view
        if (isset($_GET['view']) && is_numeric($_GET['view'])) {
            self::render_single(absint($_GET['view']));
            return;
        }

        // Trash view vs inbox view
        $in_trash   = isset($_GET['view']) && $_GET['view'] === 'trash';
        $trash_cond = $in_trash ? " WHERE is_trashed = 1" : " WHERE is_trashed = 0";

        // Filter by form type
        $filter_type = '';
        $type_cond   = '';
        if (!empty($_GET['form_type'])) {
            $filter_type = sanitize_text_field($_GET['form_type']);
            $type_cond   = $wpdb->prepare(" AND form_type = %s", $filter_type);
        }

        // Pagination
        $per_page     = 20;
        $current_page = max(1, absint($_GET['paged'] ?? 1));
        $offset       = ($current_page - 1) * $per_page;

        $total       = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table {$trash_cond}{$type_cond}");
        $total_pages = (int) ceil($total / $per_page);
        $trash_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE is_trashed = 1");
        $inbox_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE is_trashed = 0");

        $submissions = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM $table {$trash_cond}{$type_cond} ORDER BY submitted_at DESC LIMIT %d OFFSET %d",
                $per_page, $offset
            )
        );

        $form_types = $wpdb->get_col("SELECT DISTINCT form_type FROM $table WHERE is_trashed = 0 ORDER BY form_type");

        $inbox_url = admin_url('admin.php?page=axion-submissions');
        $trash_url = admin_url('admin.php?page=axion-submissions&view=trash');
?>
        <div class="wrap">
            <h1 style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">
                <span style="font-size:28px;"><?php echo $in_trash ? '🗑️' : '📨'; ?></span>
                <?php echo $in_trash ? 'Trash' : 'Form Submissions'; ?>
                <span style="background:#0EA5E9;color:#fff;padding:3px 12px;border-radius:20px;font-size:13px;font-weight:600;">
                    <?php echo $total; ?> <?php echo $in_trash ? 'in trash' : 'total'; ?>
                </span>
            </h1>

            <?php
            // Notices
            foreach (['trashed' => 'moved to trash', 'deleted' => 'permanently deleted', 'restored' => 'restored', 'emptied' => 'Trash emptied successfully.'] as $key => $msg):
                if (isset($_GET[$key])): ?>
                    <div class="notice notice-success is-dismissible">
                        <p><?php echo ($key === 'emptied') ? esc_html($msg) : (absint($_GET[$key]) . ' submission(s) ' . esc_html($msg) . '.'); ?></p>
                    </div>
                <?php endif;
            endforeach; ?>

            <!-- Inbox / Trash tabs -->
            <ul class="subsubsub" style="margin-bottom:10px;">
                <li>
                    <a href="<?php echo esc_url($inbox_url); ?>" <?php echo !$in_trash ? 'class="current" aria-current="page"' : ''; ?>>
                        Inbox <span class="count">(<?php echo $inbox_count; ?>)</span>
                    </a> |
                </li>
                <li>
                    <a href="<?php echo esc_url($trash_url); ?>" <?php echo $in_trash ? 'class="current" aria-current="page"' : ''; ?>>
                        Trash <span class="count">(<?php echo $trash_count; ?>)</span>
                    </a>
                </li>
            </ul>

            <?php if ($in_trash && $trash_count > 0): ?>
                <p>
                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=axion-submissions&view=trash&axion_empty_trash=1'), 'axion_empty_trash'); ?>"
                       class="button button-secondary"
                       onclick="return confirm('Permanently delete ALL items in trash? This cannot be undone.');">
                        🗑️ Empty Trash
                    </a>
                </p>
            <?php endif; ?>

            <!-- Filter by form type (only on inbox) -->
            <?php if (!$in_trash && !empty($form_types)): ?>
                <div style="margin:10px 0;display:flex;gap:8px;flex-wrap:wrap;">
                    <a href="<?php echo esc_url($inbox_url); ?>" class="button <?php echo empty($filter_type) ? 'button-primary' : ''; ?>">All</a>
                    <?php foreach ($form_types as $type): ?>
                        <a href="<?php echo esc_url(admin_url('admin.php?page=axion-submissions&form_type=' . urlencode($type))); ?>"
                           class="button <?php echo $filter_type === $type ? 'button-primary' : ''; ?>">
                            <?php echo esc_html($type); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <?php if (empty($submissions)): ?>
                <div style="text-align:center;padding:60px 20px;color:#666;">
                    <div style="font-size:48px;margin-bottom:10px;"><?php echo $in_trash ? '🗑️' : '📭'; ?></div>
                    <p style="font-size:16px;"><?php echo $in_trash ? 'Trash is empty.' : 'No submissions yet.'; ?></p>
                    <?php if (!$in_trash): ?><p style="color:#999;">Form submissions will appear here.</p><?php endif; ?>
                </div>
            <?php else: ?>
                <form method="POST">
                    <?php wp_nonce_field('axion_bulk_submissions'); ?>

                    <div style="margin:10px 0;display:flex;align-items:center;gap:10px;">
                        <select name="axion_bulk_action" style="min-width:160px;">
                            <option value="">Bulk Actions</option>
                            <?php if ($in_trash): ?>
                                <option value="restore">Restore Selected</option>
                                <option value="delete">Delete Permanently</option>
                            <?php else: ?>
                                <option value="trash">Move to Trash</option>
                            <?php endif; ?>
                        </select>
                        <button type="submit" class="button">Apply</button>
                    </div>

                    <table class="wp-list-table widefat fixed striped" style="border-radius:8px;overflow:hidden;">
                        <thead>
                            <tr>
                                <td style="width:30px;padding:10px;"><input type="checkbox" id="axion-select-all" /></td>
                                <th style="width:50px;">#</th>
                                <th>Form Type</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Date</th>
                                <?php if ($in_trash): ?><th>Trashed</th><?php endif; ?>
                                <th style="width:220px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($submissions as $sub):
                                $fields   = json_decode($sub->fields, true) ?: [];
                                $name     = $fields['fullName'] ?? $fields['name'] ?? $fields['full_name'] ?? '—';
                                $email    = $fields['email']    ?? $fields['Email']                        ?? '—';
                                $is_unread = !$sub->is_read && !$in_trash;
                            ?>
                                <tr style="<?php echo $is_unread ? 'background:#eef8ff;font-weight:600;' : ''; ?>">
                                    <td style="padding:10px;"><input type="checkbox" name="submission_ids[]" value="<?php echo $sub->id; ?>" /></td>
                                    <td><?php echo $sub->id; ?></td>
                                    <td>
                                        <span style="background:#e0f2fe;color:#0369a1;padding:2px 10px;border-radius:12px;font-size:12px;font-weight:600;">
                                            <?php echo esc_html($sub->form_type); ?>
                                        </span>
                                    </td>
                                    <td><?php echo esc_html($name); ?></td>
                                    <td><?php echo esc_html($email); ?></td>
                                    <td>
                                        <?php echo date('M j, Y g:i A', strtotime($sub->submitted_at)); ?>
                                        <?php if ($is_unread): ?>
                                            <span style="color:#0EA5E9;font-size:11px;"> ● NEW</span>
                                        <?php endif; ?>
                                    </td>
                                    <?php if ($in_trash): ?>
                                        <td style="color:#999;font-size:12px;">
                                            <?php echo $sub->trashed_at ? date('M j, Y', strtotime($sub->trashed_at)) : '—'; ?>
                                        </td>
                                    <?php endif; ?>
                                    <td>
                                        <?php if (!$in_trash): ?>
                                            <a href="<?php echo esc_url(admin_url('admin.php?page=axion-submissions&view=' . $sub->id)); ?>"
                                               class="button button-small">View</a>
                                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=axion-submissions&axion_trash_submission=' . $sub->id), 'axion_trash_submission'); ?>"
                                               class="button button-small" style="color:#b45309;"
                                               onclick="return confirm('Move to trash?');">Trash</a>
                                        <?php else: ?>
                                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=axion-submissions&view=trash&axion_restore_submission=' . $sub->id), 'axion_restore_submission'); ?>"
                                               class="button button-small">Restore</a>
                                            <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=axion-submissions&axion_delete_submission=' . $sub->id), 'axion_delete_submission'); ?>"
                                               class="button button-small" style="color:#dc3545;"
                                               onclick="return confirm('Permanently delete this submission? This cannot be undone.');">Delete</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </form>

                <!-- Pagination -->
                <?php if ($total_pages > 1): ?>
                    <div style="margin:20px 0;display:flex;gap:5px;justify-content:center;">
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=axion-submissions' . ($in_trash ? '&view=trash' : '') . '&paged=' . $i . ($filter_type ? '&form_type=' . urlencode($filter_type) : ''))); ?>"
                               class="button <?php echo $i === $current_page ? 'button-primary' : ''; ?>"
                               style="min-width:36px;text-align:center;"><?php echo $i; ?></a>
                        <?php endfor; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>

        <script>
        document.getElementById('axion-select-all')?.addEventListener('change', function() {
            document.querySelectorAll('input[name="submission_ids[]"]').forEach(cb => cb.checked = this.checked);
        });
        </script>
<?php
    }

    // ─── Render single submission detail ───
    private static function render_single($id)
    {
        global $wpdb;
        $sub = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . self::$table_name . " WHERE id = %d", $id));

        if (!$sub) {
            echo '<div class="wrap"><h1>Submission not found</h1><a href="' . esc_url(admin_url('admin.php?page=axion-submissions')) . '" class="button">← Back</a></div>';
            return;
        }

        // Auto mark as read
        if (!$sub->is_read) {
            $wpdb->update(self::$table_name, ['is_read' => 1], ['id' => $id], ['%d'], ['%d']);
        }

        $fields    = json_decode($sub->fields, true) ?: [];
        $back_url  = $sub->is_trashed
            ? admin_url('admin.php?page=axion-submissions&view=trash')
            : admin_url('admin.php?page=axion-submissions');
?>
        <div class="wrap">
            <div style="display:flex;align-items:center;gap:15px;margin-bottom:20px;flex-wrap:wrap;">
                <a href="<?php echo esc_url($back_url); ?>" class="button">← Back</a>
                <h1 style="margin:0;">Submission #<?php echo $sub->id; ?></h1>
                <span style="background:#e0f2fe;color:#0369a1;padding:4px 14px;border-radius:14px;font-size:13px;font-weight:600;">
                    <?php echo esc_html($sub->form_type); ?>
                </span>
                <?php if ($sub->is_trashed): ?>
                    <span style="background:#fef3c7;color:#92400e;padding:4px 14px;border-radius:14px;font-size:12px;font-weight:600;">🗑️ In Trash</span>
                <?php endif; ?>
            </div>

            <div style="background:#fff;border:1px solid #ddd;border-radius:12px;padding:30px;max-width:700px;">
                <div style="margin-bottom:20px;padding-bottom:15px;border-bottom:1px solid #eee;">
                    <small style="color:#999;">Submitted on</small>
                    <div style="font-size:15px;font-weight:600;color:#333;">
                        <?php echo date('F j, Y \a\t g:i A', strtotime($sub->submitted_at)); ?>
                    </div>
                </div>

                <?php if ($sub->ip_address): ?>
                    <div style="margin-bottom:20px;padding-bottom:15px;border-bottom:1px solid #eee;">
                        <small style="color:#999;">IP Address</small>
                        <div style="font-size:14px;color:#333;"><?php echo esc_html($sub->ip_address); ?></div>
                    </div>
                <?php endif; ?>

                <?php foreach ($fields as $key => $value): ?>
                    <div style="margin-bottom:18px;padding-bottom:15px;border-bottom:1px solid #f5f5f5;">
                        <small style="color:#999;text-transform:capitalize;">
                            <?php echo esc_html(str_replace(['_', '-'], ' ', $key)); ?>
                        </small>
                        <div style="font-size:15px;color:#1e293b;margin-top:4px;line-height:1.6;">
                            <?php echo nl2br(esc_html($value)); ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div style="margin-top:20px;display:flex;gap:10px;flex-wrap:wrap;">
                <?php if (isset($fields['email']) || isset($fields['Email'])): ?>
                    <a href="mailto:<?php echo esc_attr($fields['email'] ?? $fields['Email']); ?>" class="button button-primary">
                        📧 Reply via Email
                    </a>
                <?php endif; ?>

                <?php if (!$sub->is_trashed): ?>
                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=axion-submissions&axion_trash_submission=' . $sub->id), 'axion_trash_submission'); ?>"
                       class="button" style="color:#b45309;"
                       onclick="return confirm('Move to trash?');">
                        🗑️ Move to Trash
                    </a>
                <?php else: ?>
                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=axion-submissions&view=trash&axion_restore_submission=' . $sub->id), 'axion_restore_submission'); ?>"
                       class="button">
                        ♻️ Restore
                    </a>
                    <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=axion-submissions&axion_delete_submission=' . $sub->id), 'axion_delete_submission'); ?>"
                       class="button" style="color:#dc3545;"
                       onclick="return confirm('Permanently delete? This cannot be undone.');">
                        ❌ Delete Permanently
                    </a>
                <?php endif; ?>
            </div>
        </div>
<?php
    }
}
