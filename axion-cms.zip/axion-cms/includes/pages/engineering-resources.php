<?php
/**
 * Engineering Resources page CMS configuration
 * Slug: engineering-resources
 */

return [
    'slug'     => 'engineering-resources',
    'label'    => 'Engineering Resources',
    'sections' => [

        // ====================================================================
        // HERO
        // ====================================================================
        'hero' => [
            'label'  => 'Hero Section',
            'icon'   => '🎯',
            'fields' => [
                ['name' => 'bg_image', 'label' => '🖼 Hero Background Image', 'type' => 'image', 'description' => 'Optional full-width hero background photo. Recommended: 1920×1080px. Leave empty for default dark background.'],
                ['name' => 'accent_color', 'label' => '🎨 Accent Color', 'type' => 'color', 'default' => '#fb923c', 'description' => 'Primary accent color used on buttons, highlights, and stat values across this page.'],
                ['name' => 'label',       'label' => 'Pill Label',                  'type' => 'text',     'default' => 'ENGINEERING RESOURCES'],
                ['name' => 'heading',     'label' => 'Heading (\\n = line break)',   'type' => 'textarea', 'default' => "Technical Documentation\nfor Critical Power Systems"],
                ['name' => 'subtitle',    'label' => 'Subtitle',                    'type' => 'textarea', 'default' => 'Access the complete library of engineering resources for VRLA and wet cell battery systems.'],
                ['name' => 'panel_title', 'label' => 'Panel Title',                 'type' => 'text',     'default' => 'RESOURCE LIBRARY'],
                [
                    'name'  => 'stats',
                    'label' => 'Hero Stats',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'value', 'label' => 'Value', 'type' => 'text'],
                        ['name' => 'label', 'label' => 'Label', 'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                    ],
                ],
                [
                    'name'  => 'panel_rows',
                    'label' => 'Panel Resource Rows',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'icon',   'label' => 'Icon / Emoji',   'type' => 'text'],
                        ['name' => 'type',   'label' => 'Resource Type',  'type' => 'text'],
                        ['name' => 'format', 'label' => 'File Format',    'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['icon' => '', 'type' => '', 'format' => ''],
                        ['icon' => '', 'type' => '', 'format' => ''],
                        ['icon' => '', 'type' => '', 'format' => ''],
                        ['icon' => '', 'type' => '', 'format' => ''],
                        ['icon' => '', 'type' => '', 'format' => ''],
                        ['icon' => '', 'type' => '', 'format' => ''],
                    ],
                ],
                ['name' => 'btn1_label', 'label' => 'Primary Button Label',   'type' => 'text', 'default' => 'Browse All Resources →'],
                ['name' => 'btn1_url',   'label' => 'Primary Button URL',     'type' => 'text', 'default' => '/contact'],
                ['name' => 'btn2_label', 'label' => 'Secondary Button Label', 'type' => 'text', 'default' => 'Request a Document'],
                ['name' => 'btn2_url',   'label' => 'Secondary Button URL',   'type' => 'text', 'default' => '/contact'],
            ],
        ],

        // ====================================================================
        // RESOURCE LIBRARY
        // ====================================================================
        'resource-library' => [
            'label'  => 'Resource Library',
            'icon'   => '📁',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#ffffff', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',    'label' => 'Section Label', 'type' => 'text',     'default' => 'RESOURCE LIBRARY'],
                ['name' => 'heading',  'label' => 'Heading',       'type' => 'text',     'default' => 'Download What You Need'],
                ['name' => 'subtitle', 'label' => 'Subtitle',      'type' => 'textarea', 'default' => 'Every document is available upon request — formatted for immediate use in project specifications, submittals, and design packages.'],
                [
                    'name'  => 'resources',
                    'label' => 'Resource Cards',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon / Emoji',      'type' => 'text'],
                        ['name' => 'category',    'label' => 'Category Label',    'type' => 'text'],
                        ['name' => 'title',       'label' => 'Document Title',    'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description',       'type' => 'textarea'],
                        ['name' => 'format',      'label' => 'File Format',       'type' => 'text'],
                        ['name' => 'tags',        'label' => 'Tags (comma-sep.)', 'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                        ['icon' => '', 'category' => '', 'title' => '', 'description' => '', 'format' => '', 'tags' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // TECHNICAL GUIDES
        // ====================================================================
        'technical-guides' => [
            'label'  => 'Technical Guides',
            'icon'   => '📖',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#0a0e1a', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',    'label' => 'Section Label', 'type' => 'text',     'default' => 'TECHNICAL GUIDES'],
                ['name' => 'heading',  'label' => 'Heading',       'type' => 'text',     'default' => 'In-Depth Engineering Guides'],
                ['name' => 'subtitle', 'label' => 'Subtitle',      'type' => 'textarea', 'default' => 'Comprehensive technical references written for engineers.'],
                [
                    'name'  => 'guides',
                    'label' => 'Guide Cards',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'number',      'label' => 'Guide Number (01, 02…)', 'type' => 'text'],
                        ['name' => 'tag',         'label' => 'Tag / Type',             'type' => 'text'],
                        ['name' => 'title',       'label' => 'Guide Title',            'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description',            'type' => 'textarea'],
                        ['name' => 'topics',      'label' => 'Topics (one per line)',  'type' => 'textarea'],
                        ['name' => 'format',      'label' => 'Format (PDF, DOCX…)',    'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['number' => '', 'tag' => '', 'title' => '', 'description' => '', 'topics' => '', 'format' => ''],
                        ['number' => '', 'tag' => '', 'title' => '', 'description' => '', 'topics' => '', 'format' => ''],
                        ['number' => '', 'tag' => '', 'title' => '', 'description' => '', 'topics' => '', 'format' => ''],
                        ['number' => '', 'tag' => '', 'title' => '', 'description' => '', 'topics' => '', 'format' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // SIZING & SELECTION TOOLS
        // ====================================================================
        'sizing-tools' => [
            'label'  => 'Sizing & Selection Tools',
            'icon'   => '📏',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#ffffff', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',      'label' => 'Section Label', 'type' => 'text',     'default' => 'SIZING & SELECTION TOOLS'],
                ['name' => 'heading',    'label' => 'Heading',       'type' => 'text',     'default' => 'Engineering Tools & Worksheets'],
                ['name' => 'subtitle',   'label' => 'Subtitle',      'type' => 'textarea', 'default' => 'Structured sizing worksheets and selection tools based on IEEE and IEC standards.'],
                ['name' => 'disclaimer', 'label' => 'Disclaimer',    'type' => 'textarea', 'default' => 'All worksheets are based on published IEEE / IEC standards. Axion engineering support is available at no charge to validate results for your project.'],
                [
                    'name'  => 'tools',
                    'label' => 'Tool Cards',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'icon',         'label' => 'Icon / Emoji',         'type' => 'text'],
                        ['name' => 'title',        'label' => 'Tool Title',           'type' => 'text'],
                        ['name' => 'description',  'label' => 'Description',          'type' => 'textarea'],
                        ['name' => 'standard',     'label' => 'Standard Reference',   'type' => 'text'],
                        ['name' => 'inputs',       'label' => 'Inputs (one per line)','type' => 'textarea'],
                        ['name' => 'output_label', 'label' => 'Output Label',         'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['icon' => '', 'title' => '', 'description' => '', 'standard' => '', 'inputs' => '', 'output_label' => ''],
                        ['icon' => '', 'title' => '', 'description' => '', 'standard' => '', 'inputs' => '', 'output_label' => ''],
                        ['icon' => '', 'title' => '', 'description' => '', 'standard' => '', 'inputs' => '', 'output_label' => ''],
                        ['icon' => '', 'title' => '', 'description' => '', 'standard' => '', 'inputs' => '', 'output_label' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // APPLICATION NOTES
        // ====================================================================
        'application-notes' => [
            'label'  => 'Application Notes',
            'icon'   => '📊',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#0a0e1a', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',    'label' => 'Section Label', 'type' => 'text',     'default' => 'APPLICATION NOTES'],
                ['name' => 'heading',  'label' => 'Heading',       'type' => 'text',     'default' => 'Technical Notes by Application'],
                ['name' => 'subtitle', 'label' => 'Subtitle',      'type' => 'textarea', 'default' => 'Application-specific technical guidance for distinct facility types and power continuity requirements.'],
                [
                    'name'  => 'notes',
                    'label' => 'Application Note Cards',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'tag',        'label' => 'Industry Tag',            'type' => 'text'],
                        ['name' => 'tag_color',  'label' => 'Tag Accent Color',        'type' => 'text'],
                        ['name' => 'title',      'label' => 'Note Title',              'type' => 'text'],
                        ['name' => 'summary',    'label' => 'Summary',                 'type' => 'textarea'],
                        ['name' => 'key_points', 'label' => 'Key Points (one/line)',   'type' => 'textarea'],
                        ['name' => 'technology', 'label' => 'Battery Technology',      'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['tag' => '', 'tag_color' => '', 'title' => '', 'summary' => '', 'key_points' => '', 'technology' => ''],
                        ['tag' => '', 'tag_color' => '', 'title' => '', 'summary' => '', 'key_points' => '', 'technology' => ''],
                        ['tag' => '', 'tag_color' => '', 'title' => '', 'summary' => '', 'key_points' => '', 'technology' => ''],
                        ['tag' => '', 'tag_color' => '', 'title' => '', 'summary' => '', 'key_points' => '', 'technology' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // STANDARDS REFERENCE
        // ====================================================================
        'standards-reference' => [
            'label'  => 'Standards Quick Reference',
            'icon'   => '🛡',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#ffffff', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',    'label' => 'Section Label', 'type' => 'text',     'default' => 'STANDARDS REFERENCE'],
                ['name' => 'heading',  'label' => 'Heading',       'type' => 'text',     'default' => 'Key Standards for Battery System Design'],
                ['name' => 'subtitle', 'label' => 'Subtitle',      'type' => 'textarea', 'default' => 'Quick-reference guide to primary electrical, safety, and environmental standards.'],
                [
                    'name'  => 'standards',
                    'label' => 'Standard Cards',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'code',       'label' => 'Standard Code (e.g. IEEE 485)', 'type' => 'text'],
                        ['name' => 'body',       'label' => 'Issuing Body (IEEE, NFPA…)',    'type' => 'text'],
                        ['name' => 'title',      'label' => 'Short Title',                   'type' => 'text'],
                        ['name' => 'scope',      'label' => 'Scope / Description',           'type' => 'textarea'],
                        ['name' => 'applies_to', 'label' => 'Applies To',                    'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['code' => '', 'body' => '', 'title' => '', 'scope' => '', 'applies_to' => ''],
                        ['code' => '', 'body' => '', 'title' => '', 'scope' => '', 'applies_to' => ''],
                        ['code' => '', 'body' => '', 'title' => '', 'scope' => '', 'applies_to' => ''],
                        ['code' => '', 'body' => '', 'title' => '', 'scope' => '', 'applies_to' => ''],
                        ['code' => '', 'body' => '', 'title' => '', 'scope' => '', 'applies_to' => ''],
                        ['code' => '', 'body' => '', 'title' => '', 'scope' => '', 'applies_to' => ''],
                        ['code' => '', 'body' => '', 'title' => '', 'scope' => '', 'applies_to' => ''],
                        ['code' => '', 'body' => '', 'title' => '', 'scope' => '', 'applies_to' => ''],
                        ['code' => '', 'body' => '', 'title' => '', 'scope' => '', 'applies_to' => ''],
                        ['code' => '', 'body' => '', 'title' => '', 'scope' => '', 'applies_to' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // ENGINEERING SUPPORT
        // ====================================================================
        'engineering-support' => [
            'label'  => 'Engineering Support Programs',
            'icon'   => '🔧',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#0a0e1a', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',        'label' => 'Section Label',   'type' => 'text',     'default' => 'ENGINEERING SUPPORT'],
                ['name' => 'heading',      'label' => 'Heading',         'type' => 'text',     'default' => 'Direct Support for Engineers & Specifiers'],
                ['name' => 'subtitle',     'label' => 'Subtitle',        'type' => 'textarea', 'default' => "Axion's engineering team provides no-cost technical support to consulting engineers, specifiers, and facility managers throughout the project lifecycle."],
                ['name' => 'note_heading', 'label' => 'Note Bar Heading','type' => 'text',     'default' => 'All Support is Provided at No Charge'],
                ['name' => 'note_text',    'label' => 'Note Bar Body',   'type' => 'textarea', 'default' => "Axion's engineering support programs are available at no cost to consulting engineers, specifiers, and project managers."],
                [
                    'name'  => 'programs',
                    'label' => 'Support Program Cards',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'icon',         'label' => 'Icon / Emoji',              'type' => 'text'],
                        ['name' => 'title',        'label' => 'Program Title',             'type' => 'text'],
                        ['name' => 'description',  'label' => 'Description',               'type' => 'textarea'],
                        ['name' => 'deliverables', 'label' => 'Deliverables (one/line)',   'type' => 'textarea'],
                        ['name' => 'turnaround',   'label' => 'Typical Turnaround',        'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['icon' => '', 'title' => '', 'description' => '', 'deliverables' => '', 'turnaround' => ''],
                        ['icon' => '', 'title' => '', 'description' => '', 'deliverables' => '', 'turnaround' => ''],
                        ['icon' => '', 'title' => '', 'description' => '', 'deliverables' => '', 'turnaround' => ''],
                        ['icon' => '', 'title' => '', 'description' => '', 'deliverables' => '', 'turnaround' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // CTA
        // ====================================================================
        'cta' => [
            'label'  => 'Call to Action',
            'icon'   => '📣',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#111827', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',        'label' => 'Label',                   'type' => 'text',     'default' => 'GET STARTED'],
                ['name' => 'heading_line1','label' => 'Heading Line 1',          'type' => 'text',     'default' => 'Access the Resources'],
                ['name' => 'heading_line2','label' => 'Heading Line 2 (accent)', 'type' => 'text',     'default' => 'Your Project Needs'],
                ['name' => 'description',  'label' => 'Description',             'type' => 'textarea', 'default' => 'Request any document from the library, initiate an engineering support request, or contact Axion directly — our technical team responds fast.'],
                ['name' => 'btn1_label',   'label' => 'Primary Button Label',    'type' => 'text',     'default' => 'Request Documents'],
                ['name' => 'btn1_url',     'label' => 'Primary Button URL',      'type' => 'text',     'default' => '/contact'],
                ['name' => 'btn2_label',   'label' => 'Secondary Button Label',  'type' => 'text',     'default' => 'Contact Engineering Support →'],
                ['name' => 'btn2_url',     'label' => 'Secondary Button URL',    'type' => 'text',     'default' => '/contact'],
                ['name' => 'trust_line',   'label' => 'Trust / Support Line',    'type' => 'text',     'default' => 'No-cost resources for engineers, specifiers & facility managers — VRLA and wet cell battery systems'],
            ],
        ],

    ],
];
