<?php
/**
 * Consulting Engineer Hub page CMS configuration
 * Slug: consulting-engineer-hub
 */

return [
    'slug'     => 'consulting-engineer-hub',
    'label'    => 'Consulting Engineer Hub',
    'sections' => [

        // ====================================================================
        // HERO
        // ====================================================================
        'hero' => [
            'label'  => 'Hero Section',
            'icon'   => '🎯',
            'fields' => [
                ['name' => 'bg_image', 'label' => '🖼 Hero Background Image', 'type' => 'image', 'description' => 'Optional full-width hero background photo. Recommended: 1920×1080px. Leave empty for default dark background.'],
                ['name' => 'accent_color', 'label' => '🎨 Accent Color', 'type' => 'color', 'default' => '#38d68a', 'description' => 'Primary accent color used on buttons, highlights, and stat values across this page.'],
                ['name' => 'label',     'label' => 'Pill Label',   'type' => 'text',     'default' => 'CONSULTING ENGINEER HUB'],
                ['name' => 'heading',   'label' => 'Heading (use \\n for line breaks)', 'type' => 'textarea', 'default' => "Your Technical\nSpecification Partner"],
                ['name' => 'subtitle',  'label' => 'Subtitle',     'type' => 'textarea', 'default' => 'Axion Critical Power Solutions provides consulting engineers, specifiers, and project managers with the technical documentation, basis-of-design resources, and specification language needed to design and specify critical power battery systems with confidence.'],
                [
                    'name'  => 'stats',
                    'label' => 'Hero Stats',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'value', 'label' => 'Value', 'type' => 'text'],
                        ['name' => 'label', 'label' => 'Label', 'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                    ],
                ],
                ['name' => 'panel_title', 'label' => 'Panel Title', 'type' => 'text', 'default' => 'ENGINEERING RESOURCES'],
                [
                    'name'  => 'panel_resources',
                    'label' => 'Panel Resource Rows',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'icon',     'label' => 'Icon / Emoji',  'type' => 'text'],
                        ['name' => 'category', 'label' => 'Category Name', 'type' => 'text'],
                        ['name' => 'count',    'label' => 'Count / Status','type' => 'text'],
                    ],
                    'default_rows' => [
                        ['icon' => '', 'category' => '', 'count' => ''],
                        ['icon' => '', 'category' => '', 'count' => ''],
                        ['icon' => '', 'category' => '', 'count' => ''],
                        ['icon' => '', 'category' => '', 'count' => ''],
                        ['icon' => '', 'category' => '', 'count' => ''],
                        ['icon' => '', 'category' => '', 'count' => ''],
                    ],
                ],
                ['name' => 'btn_label', 'label' => 'CTA Button Label', 'type' => 'text', 'default' => 'Request Spec Support →'],
                ['name' => 'btn_url',   'label' => 'CTA Button URL',   'type' => 'text', 'default' => '/contact'],
            ],
        ],

        // ====================================================================
        // RESOURCES & DOWNLOADS
        // ====================================================================
        'resources-downloads' => [
            'label'  => 'Resources & Downloads',
            'icon'   => '📁',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#ffffff', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',    'label' => 'Section Label', 'type' => 'text',     'default' => 'TECHNICAL RESOURCES'],
                ['name' => 'heading',  'label' => 'Heading',       'type' => 'text',     'default' => 'Specification-Ready Technical Resources'],
                ['name' => 'subtitle', 'label' => 'Subtitle',      'type' => 'textarea', 'default' => 'Access the documentation you need to specify Axion battery systems — available for VRLA and flooded wet cell product lines.'],
                [
                    'name'  => 'cards',
                    'label' => 'Resource Cards',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon / Emoji',    'type' => 'text'],
                        ['name' => 'title',       'label' => 'Card Title',      'type' => 'text'],
                        ['name' => 'description', 'label' => 'Card Description','type' => 'textarea'],
                        ['name' => 'badge',       'label' => 'File Type Badge', 'type' => 'text'],
                        ['name' => 'link_label',  'label' => 'Link Label',      'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['icon' => '', 'title' => '', 'description' => '', 'badge' => '', 'link_label' => ''],
                        ['icon' => '', 'title' => '', 'description' => '', 'badge' => '', 'link_label' => ''],
                        ['icon' => '', 'title' => '', 'description' => '', 'badge' => '', 'link_label' => ''],
                        ['icon' => '', 'title' => '', 'description' => '', 'badge' => '', 'link_label' => ''],
                        ['icon' => '', 'title' => '', 'description' => '', 'badge' => '', 'link_label' => ''],
                        ['icon' => '', 'title' => '', 'description' => '', 'badge' => '', 'link_label' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // BATTERY SELECTION GUIDE
        // ====================================================================
        'battery-selection' => [
            'label'  => 'Battery Selection Guide',
            'icon'   => '🔋',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#0a0e1a', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',    'label' => 'Section Label', 'type' => 'text',     'default' => 'BATTERY SELECTION GUIDE'],
                ['name' => 'heading',  'label' => 'Heading',       'type' => 'text',     'default' => 'Select the Right Battery for Your Project'],
                ['name' => 'subtitle', 'label' => 'Subtitle',      'type' => 'textarea', 'default' => 'Use this reference table to match battery technology to project requirements, site conditions, and client maintenance capabilities.'],
                [
                    'name'  => 'rows',
                    'label' => 'Comparison Table Rows',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'criteria',  'label' => 'Specification Criteria', 'type' => 'text'],
                        ['name' => 'vrla',      'label' => 'VRLA Column Value',      'type' => 'textarea'],
                        ['name' => 'wet_cell',  'label' => 'Wet Cell Column Value',  'type' => 'textarea'],
                    ],
                    'default_rows' => [
                        ['criteria' => '', 'vrla' => '', 'wet_cell' => ''],
                        ['criteria' => '', 'vrla' => '', 'wet_cell' => ''],
                        ['criteria' => '', 'vrla' => '', 'wet_cell' => ''],
                        ['criteria' => '', 'vrla' => '', 'wet_cell' => ''],
                        ['criteria' => '', 'vrla' => '', 'wet_cell' => ''],
                        ['criteria' => '', 'vrla' => '', 'wet_cell' => ''],
                        ['criteria' => '', 'vrla' => '', 'wet_cell' => ''],
                        ['criteria' => '', 'vrla' => '', 'wet_cell' => ''],
                    ],
                ],
                ['name' => 'vrla_recommend',      'label' => 'VRLA Recommendation Note',      'type' => 'text', 'default' => 'Recommended for most commercial and healthcare applications'],
                ['name' => 'wet_cell_recommend', 'label' => 'Wet Cell Recommendation Note', 'type' => 'text', 'default' => 'Recommended for utility and long-lifecycle industrial applications'],
            ],
        ],

        // ====================================================================
        // SPECIFICATION SUPPORT
        // ====================================================================
        'specification-support' => [
            'label'  => 'Specification Support',
            'icon'   => '📋',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#ffffff', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',    'label' => 'Section Label', 'type' => 'text',     'default' => 'SPECIFICATION SUPPORT'],
                ['name' => 'heading',  'label' => 'Heading',       'type' => 'text',     'default' => 'End-to-End Specification Support'],
                ['name' => 'subtitle', 'label' => 'Subtitle',      'type' => 'textarea', 'default' => 'Axion works directly with consulting engineers from early design through project close — providing the technical documentation needed at every stage.'],
                [
                    'name'  => 'steps',
                    'label' => 'Support Steps / Cards',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'number',   'label' => 'Step Number (e.g. 01)',  'type' => 'text'],
                        ['name' => 'title',    'label' => 'Step Title',             'type' => 'text'],
                        ['name' => 'subtitle', 'label' => 'Step Subtitle',          'type' => 'text'],
                        ['name' => 'bullets',  'label' => 'Bullet Points (one per line)', 'type' => 'textarea'],
                    ],
                    'default_rows' => [
                        ['number' => '', 'title' => '', 'subtitle' => '', 'bullets' => ''],
                        ['number' => '', 'title' => '', 'subtitle' => '', 'bullets' => ''],
                        ['number' => '', 'title' => '', 'subtitle' => '', 'bullets' => ''],
                        ['number' => '', 'title' => '', 'subtitle' => '', 'bullets' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // STANDARDS & CODES
        // ====================================================================
        'standards-codes' => [
            'label'  => 'Standards & Codes',
            'icon'   => '🛡',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#0a0e1a', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',    'label' => 'Section Label', 'type' => 'text',     'default' => 'STANDARDS & CODES'],
                ['name' => 'heading',  'label' => 'Heading',       'type' => 'text',     'default' => 'Designed and Specified to Industry Standards'],
                ['name' => 'subtitle', 'label' => 'Subtitle',      'type' => 'textarea', 'default' => 'Axion battery systems are specified in alignment with the applicable electrical, safety, and environmental standards — so your documentation is code-compliant from day one.'],
                [
                    'name'  => 'standards',
                    'label' => 'Standards Grid Cards',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'code',        'label' => 'Standard Code (e.g. IEEE 485)', 'type' => 'text'],
                        ['name' => 'title',       'label' => 'Short Title',                   'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description',                   'type' => 'textarea'],
                    ],
                    'default_rows' => [
                        ['code' => '', 'title' => '', 'description' => ''],
                        ['code' => '', 'title' => '', 'description' => ''],
                        ['code' => '', 'title' => '', 'description' => ''],
                        ['code' => '', 'title' => '', 'description' => ''],
                        ['code' => '', 'title' => '', 'description' => ''],
                        ['code' => '', 'title' => '', 'description' => ''],
                        ['code' => '', 'title' => '', 'description' => ''],
                        ['code' => '', 'title' => '', 'description' => ''],
                    ],
                ],
                [
                    'name'  => 'compliance_points',
                    'label' => 'Compliance Checklist Points',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'text', 'label' => 'Compliance Point', 'type' => 'textarea'],
                    ],
                    'default_rows' => [
                        ['text' => ''],
                        ['text' => ''],
                        ['text' => ''],
                        ['text' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // PROJECT APPLICATIONS
        // ====================================================================
        'project-applications' => [
            'label'  => 'Project Applications',
            'icon'   => '🏭',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#ffffff', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',    'label' => 'Section Label', 'type' => 'text',     'default' => 'PROJECT APPLICATIONS'],
                ['name' => 'heading',  'label' => 'Heading',       'type' => 'text',     'default' => 'Specified Across Critical Industries'],
                ['name' => 'subtitle', 'label' => 'Subtitle',      'type' => 'textarea', 'default' => 'Axion battery systems appear in specifications for a wide range of critical facility types — each with unique power continuity requirements.'],
                [
                    'name'  => 'apps',
                    'label' => 'Application Cards',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'tag',         'label' => 'Industry Tag',      'type' => 'text'],
                        ['name' => 'title',       'label' => 'Card Title',        'type' => 'text'],
                        ['name' => 'description', 'label' => 'Card Description',  'type' => 'textarea'],
                        ['name' => 'spec',       'label' => 'Spec Reference',    'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['tag' => '', 'title' => '', 'description' => '', 'spec' => ''],
                        ['tag' => '', 'title' => '', 'description' => '', 'spec' => ''],
                        ['tag' => '', 'title' => '', 'description' => '', 'spec' => ''],
                        ['tag' => '', 'title' => '', 'description' => '', 'spec' => ''],
                        ['tag' => '', 'title' => '', 'description' => '', 'spec' => ''],
                        ['tag' => '', 'title' => '', 'description' => '', 'spec' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // WHY AXION FOR ENGINEERS
        // ====================================================================
        'why-axion' => [
            'label'  => 'Why Axion for Engineers',
            'icon'   => '⭐',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#0a0e1a', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',    'label' => 'Section Label', 'type' => 'text', 'default' => 'WHY AXION'],
                ['name' => 'heading',  'label' => 'Heading',       'type' => 'text', 'default' => 'Built for How Engineers Actually Work'],
                [
                    'name'  => 'stats',
                    'label' => 'Stats Strip',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'value', 'label' => 'Stat Value', 'type' => 'text'],
                        ['name' => 'label', 'label' => 'Stat Label', 'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                    ],
                ],
                [
                    'name'  => 'reasons',
                    'label' => 'Reason Cards',
                    'type'  => 'repeater',
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon / Emoji',    'type' => 'text'],
                        ['name' => 'title',       'label' => 'Card Title',      'type' => 'text'],
                        ['name' => 'description', 'label' => 'Card Description','type' => 'textarea'],
                    ],
                    'default_rows' => [
                        ['icon' => '', 'title' => '', 'description' => ''],
                        ['icon' => '', 'title' => '', 'description' => ''],
                        ['icon' => '', 'title' => '', 'description' => ''],
                        ['icon' => '', 'title' => '', 'description' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // CTA
        // ====================================================================
        'cta' => [
            'label'  => 'Call to Action',
            'icon'   => '📣',
            'fields' => [
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#1565c0', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                ['name' => 'label',           'label' => 'Label',                   'type' => 'text',     'default' => 'READY TO SPECIFY?'],
                ['name' => 'heading_line1',   'label' => 'Heading Line 1',          'type' => 'text',     'default' => 'Partner With Axion on'],
                ['name' => 'heading_line2',   'label' => 'Heading Line 2 (accent)', 'type' => 'text',     'default' => 'Your Next Critical Power Project'],
                ['name' => 'description',     'label' => 'Description',             'type' => 'textarea', 'default' => 'Whether you need a datasheet, a CSI specification section, or a full basis-of-design package — our engineering support team is ready to assist.'],
                ['name' => 'btn1_label',      'label' => 'Primary Button Label',    'type' => 'text',     'default' => 'Request Spec Support'],
                ['name' => 'btn1_url',        'label' => 'Primary Button URL',      'type' => 'text',     'default' => '/contact'],
                ['name' => 'btn2_label',      'label' => 'Secondary Button Label',  'type' => 'text',     'default' => 'Download Resources →'],
                ['name' => 'btn2_url',        'label' => 'Secondary Button URL',    'type' => 'text',     'default' => '/contact'],
                ['name' => 'trust_line',      'label' => 'Trust / Support Line',    'type' => 'text',     'default' => 'No-cost specification support for consulting engineers, specifiers & project managers'],
            ],
        ],

    ],
];
