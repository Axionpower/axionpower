<?php
/**
 * Axion CMS – Replacement & Upgrades Page Config
 * Every section and field here is independently editable in the WordPress admin.
 * Default values are served via GraphQL so Next.js never needs hardcoded fallbacks.
 */
if (!defined('ABSPATH')) exit;

return [
    'slug'  => 'replacement-upgrades',
    'label' => 'Replacement & Upgrades',
    'sections' => [

        // ═══════════════════════════════════════
        // HERO SECTION
        // ═══════════════════════════════════════
        'hero' => [
            'label' => 'Hero Section',
            'icon'  => '🎯',
            'fields' => [
                ['name' => 'breadcrumb',   'label' => 'Breadcrumb Text',   'type' => 'text',     'default' => 'HOME  /  SERVICES  /  REPLACEMENT & UPGRADES'],
                ['name' => 'heading',      'label' => 'Heading',           'type' => 'text',     'default' => 'Battery Replacement & Technology Upgrades'],
                ['name' => 'subtitle',     'label' => 'Subtitle',          'type' => 'textarea', 'rows' => 3, 'default' => 'End-to-end battery replacement planning, technology upgrades, and certified disposal — keeping your critical systems current and compliant.'],
                ['name' => 'trust_badge',  'label' => 'Trust Badge Text',  'type' => 'text',     'default' => '♻️  Certified disposal & compliant upgrades'],
                ['name' => 'btn1_label',   'label' => 'Button 1 Label',    'type' => 'text',     'default' => 'Plan Your Replacement →'],
                ['name' => 'btn1_url',     'label' => 'Button 1 URL',      'type' => 'text',     'default' => '/contact'],
                ['name' => 'btn2_label',   'label' => 'Button 2 Label',    'type' => 'text',     'default' => 'Explore Upgrades'],
                ['name' => 'btn2_url',     'label' => 'Button 2 URL',      'type' => 'text',     'default' => '/contact'],
                [
                    'name'         => 'dashboard_bars',
                    'label'        => 'Dashboard Progress Bars',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['label' => 'Battery Health',    'status' => 'CRITICAL',  'pct' => '23', 'color' => '#ef4444'],
                        ['label' => 'Capacity Test',     'status' => 'DUE',       'pct' => '67', 'color' => '#f59e0b'],
                        ['label' => 'Lifecycle Status',  'status' => 'REVIEW',    'pct' => '78', 'color' => '#f59e0b'],
                        ['label' => 'Replacement Ready', 'status' => 'SCHEDULED', 'pct' => '95', 'color' => '#22c55e'],
                    ],
                    'sub_fields' => [
                        ['name' => 'label',  'label' => 'Label',      'type' => 'text'],
                        ['name' => 'status', 'label' => 'Status Tag',  'type' => 'text'],
                        ['name' => 'pct',    'label' => 'Progress %',  'type' => 'text'],
                        ['name' => 'color',  'label' => 'Bar Colour',  'type' => 'color'],
                    ],
                ],
                [
                    'name'         => 'badges',
                    'label'        => 'Hero Badges',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['text' => 'Zero Downtime'],
                        ['text' => 'Certified Disposal'],
                        ['text' => 'All Technologies'],
                        ['text' => '24/7 Support'],
                    ],
                    'sub_fields' => [
                        ['name' => 'text', 'label' => 'Badge Text', 'type' => 'text'],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // INTRO / SERVICES SECTION
        // ═══════════════════════════════════════
        'intro' => [
            'label' => 'Intro / Services Section',
            'icon'  => '📋',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'OUR SERVICES'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Complete Battery Replacement & Upgrade Services'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 4, 'default' => 'Axion Critical Power Solutions delivers expert battery replacement planning, technology upgrade pathways, and certified disposal — ensuring your mission-critical systems always operate at peak performance.'],
                ['name' => 'btn1_label',  'label' => 'Button 1 Label','type' => 'text',     'default' => 'Plan Replacement →'],
                ['name' => 'btn1_url',    'label' => 'Button 1 URL',  'type' => 'text',     'default' => '/contact'],
                ['name' => 'btn2_label',  'label' => 'Button 2 Label','type' => 'text',     'default' => 'Explore Upgrades'],
                ['name' => 'btn2_url',    'label' => 'Button 2 URL',  'type' => 'text',     'default' => '/contact'],
                [
                    'name'         => 'services',
                    'label'        => 'Service Panels',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['icon' => '🔋', 'title' => 'Battery Replacement',       'description' => 'Planned and emergency battery string replacement with full compliance documentation.'],
                        ['icon' => '⚡', 'title' => 'Technology Upgrades',        'description' => 'Upgrade from legacy VRLA or wet cell to modern, high-performance alternatives.'],
                        ['icon' => '♻️', 'title' => 'Certified Disposal',         'description' => 'Environmentally compliant battery disposal and recycling coordination.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon (emoji)',   'type' => 'text'],
                        ['name' => 'title',       'label' => 'Title',          'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description',    'type' => 'textarea', 'rows' => 3],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // PLANNING SECTION
        // ═══════════════════════════════════════
        'planning' => [
            'label' => 'Replacement Planning Section',
            'icon'  => '📐',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'REPLACEMENT PLANNING'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Expert Battery Replacement Planning'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 4, 'default' => "Axion's systematic approach ensures every battery replacement is planned, executed, and commissioned with minimal disruption to your operations."],
                ['name' => 'trust_badge', 'label' => 'Trust Badge',   'type' => 'text',     'default' => '✓ Zero-downtime replacement guaranteed'],
                [
                    'name'         => 'steps',
                    'label'        => 'Process Steps',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['num' => '01', 'icon' => '🔍', 'title' => 'Site Assessment',      'items' => "Existing battery audit\nLoad profile review\nRuntime calculations"],
                        ['num' => '02', 'icon' => '📋', 'title' => 'Replacement Scoping',  'items' => "Battery selection\nScheduling & logistics\nCompliance requirements"],
                        ['num' => '03', 'icon' => '⚡', 'title' => 'Coordinated Delivery',  'items' => "Phased delivery\nInstallation coordination\nMinimal downtime"],
                        ['num' => '04', 'icon' => '✅', 'title' => 'Commissioning',         'items' => "Acceptance testing\nDocumentation handover\nWarranty activation"],
                    ],
                    'sub_fields' => [
                        ['name' => 'num',   'label' => 'Step Number', 'type' => 'text'],
                        ['name' => 'icon',  'label' => 'Icon (emoji)','type' => 'text'],
                        ['name' => 'title', 'label' => 'Title',       'type' => 'text'],
                        ['name' => 'items', 'label' => 'Bullet Items (one per line)', 'type' => 'textarea', 'rows' => 4],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // UPGRADES SECTION
        // ═══════════════════════════════════════
        'upgrades' => [
            'label' => 'Technology Upgrades Section',
            'icon'  => '🔄',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'TECHNOLOGY UPGRADES'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Upgrade to the Latest Battery Technology'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 3, 'default' => 'Axion provides clear upgrade pathways from legacy battery systems to modern, high-performance technologies — improving reliability, runtime, and total cost of ownership.'],
                ['name' => 'btn1_label',  'label' => 'Button 1 Label','type' => 'text',     'default' => 'Discuss Upgrade Options →'],
                ['name' => 'btn1_url',    'label' => 'Button 1 URL',  'type' => 'text',     'default' => '/contact'],
                ['name' => 'btn2_label',  'label' => 'Button 2 Label','type' => 'text',     'default' => 'Compare Technologies'],
                ['name' => 'btn2_url',    'label' => 'Button 2 URL',  'type' => 'text',     'default' => '/contact'],
                [
                    'name'         => 'techs',
                    'label'        => 'Technology Cards',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['icon' => '🔋', 'name' => 'VRLA AGM',     'subtitle' => 'Valve-Regulated Lead-Acid', 'badge' => 'Standard', 'progress' => '55', 'description' => 'Maintenance-free sealed batteries for controlled environments.'],
                        ['icon' => '⚡', 'name' => 'Wet Cell',      'subtitle' => 'Flooded Lead-Acid',         'badge' => 'Heavy Duty','progress' => '70', 'description' => 'Long-life batteries for demanding industrial applications.'],
                        ['icon' => '🚀', 'name' => 'Lithium-Ion',   'subtitle' => 'Next-Generation Power',     'badge' => 'Premium',   'progress' => '98', 'description' => 'High-density, fast-charging technology for modern critical systems.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon (emoji)',     'type' => 'text'],
                        ['name' => 'name',        'label' => 'Technology Name',  'type' => 'text'],
                        ['name' => 'subtitle',    'label' => 'Subtitle',         'type' => 'text'],
                        ['name' => 'badge',       'label' => 'Badge Label',      'type' => 'text'],
                        ['name' => 'progress',    'label' => 'Progress % (0-100)','type' => 'number', 'min' => 0, 'max' => 100],
                        ['name' => 'description', 'label' => 'Description',      'type' => 'textarea', 'rows' => 2],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // DISPOSAL SECTION
        // ═══════════════════════════════════════
        'disposal' => [
            'label' => 'Disposal & Recycling Section',
            'icon'  => '♻️',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'DISPOSAL & RECYCLING'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Certified Battery Disposal & Recycling'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 3, 'default' => 'Axion provides fully certified, environmentally responsible battery disposal and recycling services — ensuring compliance with all regulatory requirements.'],
                [
                    'name'         => 'cards',
                    'label'        => 'Feature Cards',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['icon' => '📋', 'title' => 'Regulatory Compliance', 'description' => 'Full compliance with EPA, RCRA, provincial, and municipal battery disposal regulations.'],
                        ['icon' => '♻️', 'title' => '99.5% Lead Recovery',   'description' => 'Industry-leading lead recovery rate through certified recycling partners.'],
                        ['icon' => '📄', 'title' => 'Full Documentation',     'description' => 'Chain of custody certificates, manifests, and recycling records provided.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon (emoji)', 'type' => 'text'],
                        ['name' => 'title',       'label' => 'Title',        'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description',  'type' => 'textarea', 'rows' => 2],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // BENEFITS SECTION
        // ═══════════════════════════════════════
        'benefits' => [
            'label' => 'Benefits / Why Axion Section',
            'icon'  => '⭐',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'WHY CHOOSE AXION'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Benefits of Planned Replacement & Upgrades'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 3, 'default' => 'Trusted by engineers & operators across mission-critical industries to deliver seamless replacement and upgrade solutions.'],
                [
                    'name'         => 'stats',
                    'label'        => 'Stats',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['value' => '500+',   'label' => 'Replacements Completed'],
                        ['value' => '99.5%',  'label' => 'Lead Recovery Rate'],
                        ['value' => '0',      'label' => 'Downtime Incidents'],
                        ['value' => '20+ yr', 'label' => 'Industry Experience'],
                    ],
                    'sub_fields' => [
                        ['name' => 'value', 'label' => 'Value', 'type' => 'text'],
                        ['name' => 'label', 'label' => 'Label', 'type' => 'text'],
                    ],
                ],
                [
                    'name'         => 'benefits',
                    'label'        => 'Benefit Cards',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['icon' => '⚡', 'title' => 'Maximise Uptime',          'description' => 'Planned replacement prevents unexpected failures and unplanned outages.'],
                        ['icon' => '💰', 'title' => 'Reduce Total Cost',        'description' => 'Upgrade pathways lower long-term TCO compared to emergency replacements.'],
                        ['icon' => '✅', 'title' => 'Maintain Compliance',       'description' => 'All replacements and disposals are fully documented and standards-aligned.'],
                        ['icon' => '🔋', 'title' => 'Extend System Life',       'description' => 'Proactive replacement programmes extend overall system service life.'],
                        ['icon' => '📊', 'title' => 'Better Performance',       'description' => 'Modern battery technologies deliver improved runtime and reliability.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon (emoji)', 'type' => 'text'],
                        ['name' => 'title',       'label' => 'Title',        'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description',  'type' => 'textarea', 'rows' => 2],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // INDUSTRIES SECTION
        // ═══════════════════════════════════════
        'industries' => [
            'label' => 'Industries Supported Section',
            'icon'  => '🏭',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'INDUSTRIES SUPPORTED'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Replacement & Upgrade Services for Every Sector'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 3, 'default' => 'Axion delivers battery replacement and upgrade services across all mission-critical industries, ensuring compliance and continuity.'],
                [
                    'name'         => 'industries',
                    'label'        => 'Industry Cards',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['icon' => '🏥', 'title' => 'Healthcare',              'description' => 'Life-safety UPS and DC backup systems in hospitals and clinics.'],
                        ['icon' => '🏭', 'title' => 'Industrial & Manufacturing','description' => 'Process control and safety interlock battery systems.'],
                        ['icon' => '⚡', 'title' => 'Utilities & Substations',  'description' => 'IEEE-compliant VRLA and flooded battery replacements.'],
                        ['icon' => '📡', 'title' => 'Telecommunications',       'description' => 'Central office and cell site battery lifecycle management.'],
                        ['icon' => '🏦', 'title' => 'Finance & Banking',        'description' => 'Tier-certified data center and critical facility upgrades.'],
                        ['icon' => '🏛️', 'title' => 'Government',               'description' => 'Secure, compliant replacement for government infrastructure.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon (emoji)', 'type' => 'text'],
                        ['name' => 'title',       'label' => 'Title',        'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description',  'type' => 'textarea', 'rows' => 2],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // LIFECYCLE SECTION
        // ═══════════════════════════════════════
        'lifecycle' => [
            'label' => 'Lifecycle Integration Section',
            'icon'  => '🔁',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'INTEGRATED APPROACH'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Integrated Lifecycle Support'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 3, 'default' => 'Replacement, upgrades, and disposal are the final stages of Axion\'s lifecycle approach — ensuring every system is responsibly retired and replaced with optimal technology.'],
                [
                    'name'         => 'features',
                    'label'        => 'Feature Cards',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['icon' => '📊', 'title' => 'Battery Health Monitoring', 'description' => 'Continuous monitoring to predict replacement needs before failure.'],
                        ['icon' => '📅', 'title' => 'Scheduled Maintenance',     'description' => 'Proactive maintenance programmes aligned with manufacturer guidelines.'],
                        ['icon' => '🔄', 'title' => 'Replacement Coordination',  'description' => 'End-to-end logistics from old battery removal to new system commissioning.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon (emoji)', 'type' => 'text'],
                        ['name' => 'title',       'label' => 'Title',        'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description',  'type' => 'textarea', 'rows' => 2],
                    ],
                ],
                [
                    'name'         => 'steps',
                    'label'        => 'Timeline Steps',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['num' => '01', 'label' => 'Procurement',     'active' => '0'],
                        ['num' => '02', 'label' => 'Installation',    'active' => '0'],
                        ['num' => '03', 'label' => 'Commissioning',   'active' => '0'],
                        ['num' => '04', 'label' => 'Monitoring',      'active' => '0'],
                        ['num' => '05', 'label' => 'Assessment',      'active' => '1'],
                        ['num' => '06', 'label' => 'Replacement',     'active' => '1'],
                        ['num' => '07', 'label' => 'Disposal',        'active' => '1'],
                    ],
                    'sub_fields' => [
                        ['name' => 'num',    'label' => 'Step Number', 'type' => 'text'],
                        ['name' => 'label',  'label' => 'Label',       'type' => 'text'],
                        ['name' => 'active', 'label' => 'Active (1=yes, 0=no)', 'type' => 'text'],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // CTA SECTION
        // ═══════════════════════════════════════
        'cta' => [
            'label' => 'CTA Section',
            'icon'  => '📞',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'GET STARTED'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Ready to Replace or Upgrade Your Battery Systems?'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 3, 'default' => 'Talk to an Axion specialist today — we\'ll assess your current systems, recommend the right replacement or upgrade path, and manage the entire process.'],
                ['name' => 'btn1_label',  'label' => 'Button 1 Label','type' => 'text',     'default' => 'Plan Your Replacement →'],
                ['name' => 'btn1_url',    'label' => 'Button 1 URL',  'type' => 'text',     'default' => '/contact'],
                ['name' => 'btn2_label',  'label' => 'Button 2 Label','type' => 'text',     'default' => 'Request Engineering Review'],
                ['name' => 'btn2_url',    'label' => 'Button 2 URL',  'type' => 'text',     'default' => '/contact'],
                ['name' => 'btn3_label',  'label' => 'Button 3 Label','type' => 'text',     'default' => 'Download Upgrade Guide →'],
                ['name' => 'btn3_url',    'label' => 'Button 3 URL',  'type' => 'text',     'default' => '/contact'],
                [
                    'name'         => 'cards',
                    'label'        => 'Service Cards',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['icon' => '🚨', 'badge' => 'URGENT', 'badge_color' => '#ef4444', 'title' => 'Emergency Replacement',  'description' => 'Critical battery failure? Our emergency team responds within hours.'],
                        ['icon' => '📅', 'badge' => 'FREE',   'badge_color' => '#22c55e', 'title' => 'Free Lifecycle Assessment','description' => 'No obligation audit of your existing battery assets and replacement timeline.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon (emoji)',   'type' => 'text'],
                        ['name' => 'badge',       'label' => 'Badge Text',     'type' => 'text'],
                        ['name' => 'badge_color', 'label' => 'Badge Colour',   'type' => 'color'],
                        ['name' => 'title',       'label' => 'Title',          'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description',    'type' => 'textarea', 'rows' => 2],
                    ],
                ],
            ],
        ],

    ],
];
