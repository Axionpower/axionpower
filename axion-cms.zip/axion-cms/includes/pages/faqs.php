<?php
/**
 * FAQs page CMS configuration
 * Slug: faqs
 */

return [
    'slug'     => 'faqs',
    'label'    => 'FAQs',
    'sections' => [

        // ====================================================================
        // HERO
        // ====================================================================
        'hero' => [
            'label'  => 'Hero Section',
            'icon'   => '🎯',
            'fields' => [
                ['name' => 'label', 'label' => 'Pill Label', 'type' => 'text', 'default' => 'CRITICAL POWER BATTERY SYSTEMS'],
                ['name' => 'heading', 'label' => 'Heading (use \\n for line breaks)', 'type' => 'textarea', 'default' => "Answers for\nCritical Power\nBattery Systems"],
                ['name' => 'subtitle', 'label' => 'Subtitle', 'type' => 'textarea', 'default' => 'Clear, reliable answers to common questions about battery performance, maintenance, warranties, and end-of-life management — for engineers, consultants, and facility managers.'],
                ['name' => 'btn_label', 'label' => 'CTA Button Label', 'type' => 'text', 'default' => 'View Full FAQs for Engineers & Buyers →'],
                ['name' => 'btn_url', 'label' => 'CTA Button URL', 'type' => 'text', 'default' => '/contact'],
                ['name' => 'bg_image', 'label' => '🖼 Hero Background Image', 'type' => 'image', 'description' => 'Optional full-width hero background photo. Recommended: 1920×1080px. Leave empty to use the default dark background.'],
                ['name' => 'accent_color', 'label' => '🎨 Accent Color', 'type' => 'color', 'default' => '#f5c714', 'description' => 'Primary accent color for this page (buttons, highlights, stat values). Default shown.'],
                [
                    'name' => 'stats',
                    'label' => 'Hero Stats',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'value', 'label' => 'Value', 'type' => 'text'],
                        ['name' => 'label', 'label' => 'Label', 'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                        ['value' => '', 'label' => ''],
                    ],
                ],
                [
                    'name' => 'topics',
                    'label' => 'Topic Navigator Items',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'number',   'label' => 'Number (e.g. 01)', 'type' => 'text'],
                        ['name' => 'label',    'label' => 'Topic Label',      'type' => 'text'],
                        ['name' => 'sublabel', 'label' => 'Sub-label',        'type' => 'text'],
                        ['name' => 'color',    'label' => 'Accent Color',     'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['number' => '', 'label' => '', 'sublabel' => '', 'color' => ''],
                        ['number' => '', 'label' => '', 'sublabel' => '', 'color' => ''],
                        ['number' => '', 'label' => '', 'sublabel' => '', 'color' => ''],
                        ['number' => '', 'label' => '', 'sublabel' => '', 'color' => ''],
                        ['number' => '', 'label' => '', 'sublabel' => '', 'color' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // LIFESPAN & MAINTENANCE
        // ====================================================================
        'lifespan-maintenance' => [
            'label'  => 'Battery Lifespan & Maintenance',
            'icon'   => '🔋',
            'fields' => [
                ['name' => 'label', 'label' => 'Section Label', 'type' => 'text', 'default' => 'BATTERY LIFESPAN & MAINTENANCE'],
                ['name' => 'q1', 'label' => 'Question 1', 'type' => 'text', 'default' => 'How long do VRLA and flooded (wet cell) batteries last?'],
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#0a0e1a', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                [
                    'name' => 'q1_bullets',
                    'label' => 'Question 1 — Answer Bullets',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'text', 'label' => 'Bullet Point', 'type' => 'textarea'],
                    ],
                    'default_rows' => [
                        ['text' => ''],
                        ['text' => ''],
                        ['text' => ''],
                    ],
                ],
                [
                    'name' => 'lifespan_bars',
                    'label' => 'Lifespan Comparison Bars',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'type',   'label' => 'Battery Type (e.g. VRLA)', 'type' => 'text'],
                        ['name' => 'range',  'label' => 'Range Label',              'type' => 'text'],
                        ['name' => 'min_yr', 'label' => 'Min Year Label',           'type' => 'text'],
                        ['name' => 'max_yr', 'label' => 'Max Year Label',           'type' => 'text'],
                        ['name' => 'color',  'label' => 'Bar Color',                'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['type' => '', 'range' => '', 'min_yr' => '', 'max_yr' => '', 'color' => ''],
                        ['type' => '', 'range' => '', 'min_yr' => '', 'max_yr' => '', 'color' => ''],
                    ],
                ],
                ['name' => 'q2', 'label' => 'Question 2', 'type' => 'text', 'default' => 'What maintenance is required for VRLA and wet cell batteries?'],
                [
                    'name' => 'maintenance_cards',
                    'label' => 'Maintenance Cards',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'badge',       'label' => 'Badge Text',       'type' => 'text'],
                        ['name' => 'badge_color', 'label' => 'Badge Color',      'type' => 'text'],
                        ['name' => 'title',       'label' => 'Card Title',       'type' => 'text'],
                        ['name' => 'subtitle',    'label' => 'Card Subtitle',    'type' => 'text'],
                        ['name' => 'items',       'label' => 'Bullet Points (one per line)', 'type' => 'textarea'],
                    ],
                    'default_rows' => [
                        ['badge' => '', 'badge_color' => '', 'title' => '', 'subtitle' => '', 'items' => ''],
                        ['badge' => '', 'badge_color' => '', 'title' => '', 'subtitle' => '', 'items' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // LEAD TIMES & WARRANTY
        // ====================================================================
        'lead-times-warranty' => [
            'label'  => 'Lead Times & Warranty',
            'icon'   => '⏱',
            'fields' => [
                ['name' => 'label', 'label' => 'Section Label', 'type' => 'text', 'default' => 'LEAD TIMES & WARRANTY'],
                ['name' => 'q3', 'label' => 'Question 3', 'type' => 'text', 'default' => 'What are typical lead times for battery orders?'],
                ['name' => 'lead_time_headline', 'label' => 'Lead Time Headline', 'type' => 'text', 'default' => '2 – 8 WEEKS TYPICAL'],
                ['name' => 'lead_time_desc', 'label' => 'Lead Time Description', 'type' => 'textarea', 'default' => 'Lead times depend on battery type, size, quantity, and project requirements. Axion coordinates directly with manufacturers to provide accurate delivery schedules.'],
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#ffffff', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                [
                    'name' => 'lead_steps',
                    'label' => 'Lead Time Process Steps',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'step', 'label' => 'Step Label', 'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['step' => ''],
                        ['step' => ''],
                        ['step' => ''],
                        ['step' => ''],
                    ],
                ],
                [
                    'name' => 'factors',
                    'label' => 'Factors Affecting Lead Times',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'label',  'label' => 'Factor Label',  'type' => 'text'],
                        ['name' => 'detail', 'label' => 'Factor Detail', 'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['label' => '', 'detail' => ''],
                        ['label' => '', 'detail' => ''],
                        ['label' => '', 'detail' => ''],
                        ['label' => '', 'detail' => ''],
                    ],
                ],
                ['name' => 'q4', 'label' => 'Question 4', 'type' => 'text', 'default' => 'What warranties are offered on batteries?'],
                ['name' => 'warranty_intro', 'label' => 'Warranty Introduction', 'type' => 'textarea', 'default' => 'VRLA and wet cell batteries come with manufacturer warranties covering defects in materials and workmanship.'],
                [
                    'name' => 'warranty_badges',
                    'label' => 'Warranty Badges',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'badge', 'label' => 'Badge Text', 'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['badge' => ''],
                        ['badge' => ''],
                        ['badge' => ''],
                    ],
                ],
                [
                    'name' => 'warranty_points',
                    'label' => 'Warranty Bullet Points',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'text', 'label' => 'Point Text', 'type' => 'textarea'],
                    ],
                    'default_rows' => [
                        ['text' => ''],
                        ['text' => ''],
                        ['text' => ''],
                        ['text' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // END-OF-LIFE
        // ====================================================================
        'end-of-life' => [
            'label'  => 'End-of-Life Handling',
            'icon'   => '♻️',
            'fields' => [
                ['name' => 'label', 'label' => 'Section Label', 'type' => 'text', 'default' => 'END-OF-LIFE HANDLING'],
                ['name' => 'q5', 'label' => 'Question 5', 'type' => 'text', 'default' => 'How should batteries be disposed of or recycled?'],
                ['name' => 'q5_intro', 'label' => 'Answer Introduction', 'type' => 'textarea', 'default' => 'Axion provides environmentally responsible battery recycling in coordination with certified partners, ensuring compliance with federal, provincial, and local regulations.'],
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#0a0e1a', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                [
                    'name' => 'recycling_steps',
                    'label' => 'Recycling Process Steps',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'number',      'label' => 'Step Number',      'type' => 'text'],
                        ['name' => 'title',       'label' => 'Step Title',       'type' => 'text'],
                        ['name' => 'description', 'label' => 'Step Description', 'type' => 'textarea'],
                    ],
                    'default_rows' => [
                        ['number' => '', 'title' => '', 'description' => ''],
                        ['number' => '', 'title' => '', 'description' => ''],
                        ['number' => '', 'title' => '', 'description' => ''],
                        ['number' => '', 'title' => '', 'description' => ''],
                    ],
                ],
                [
                    'name' => 'compliance_rows',
                    'label' => 'Compliance Table Rows',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'standard', 'label' => 'Standard / Regulation', 'type' => 'text'],
                        ['name' => 'detail',   'label' => 'Detail',                'type' => 'text'],
                    ],
                    'default_rows' => [
                        ['standard' => '', 'detail' => ''],
                        ['standard' => '', 'detail' => ''],
                        ['standard' => '', 'detail' => ''],
                        ['standard' => '', 'detail' => ''],
                        ['standard' => '', 'detail' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // WHY FAQS MATTER
        // ====================================================================
        'why-faqs-matter' => [
            'label'  => 'Why FAQs Matter',
            'icon'   => '⭐',
            'fields' => [
                ['name' => 'label', 'label' => 'Section Label', 'type' => 'text', 'default' => 'WHY THIS MATTERS'],
                ['name' => 'heading', 'label' => 'Heading (use \\n for line breaks)', 'type' => 'textarea', 'default' => "FAQs That Build\nConfidence & Clarity"],
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#ffffff', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
                [
                    'name' => 'cards',
                    'label' => 'Benefit Cards',
                    'type' => 'repeater',
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon / Emoji',   'type' => 'text'],
                        ['name' => 'title',       'label' => 'Card Title',     'type' => 'text'],
                        ['name' => 'description', 'label' => 'Card Body Text', 'type' => 'textarea'],
                    ],
                    'default_rows' => [
                        ['icon' => '', 'title' => '', 'description' => ''],
                        ['icon' => '', 'title' => '', 'description' => ''],
                        ['icon' => '', 'title' => '', 'description' => ''],
                        ['icon' => '', 'title' => '', 'description' => ''],
                    ],
                ],
            ],
        ],

        // ====================================================================
        // CTA
        // ====================================================================
        'cta' => [
            'label'  => 'Call to Action',
            'icon'   => '📣',
            'fields' => [
                ['name' => 'label', 'label' => 'Label', 'type' => 'text', 'default' => 'HAVE MORE QUESTIONS?'],
                ['name' => 'heading_line1', 'label' => 'Heading Line 1', 'type' => 'text', 'default' => 'Get Expert Answers from'],
                ['name' => 'heading_line2', 'label' => 'Heading Line 2 (accent)', 'type' => 'text', 'default' => 'Axion Critical Power Solutions'],
                ['name' => 'description', 'label' => 'Description', 'type' => 'textarea', 'default' => 'Whether you\'re selecting batteries, planning maintenance, or managing end-of-life — our technical team is ready.'],
                ['name' => 'btn1_label', 'label' => 'Primary Button Label', 'type' => 'text', 'default' => 'Contact Axion Today'],
                ['name' => 'btn1_url', 'label' => 'Primary Button URL', 'type' => 'text', 'default' => '/contact'],
                ['name' => 'btn2_label', 'label' => 'Secondary Button Label', 'type' => 'text', 'default' => 'View All FAQs →'],
                ['name' => 'btn2_url', 'label' => 'Secondary Button URL', 'type' => 'text', 'default' => '/contact'],
                ['name' => 'trust_line', 'label' => 'Trust / Support Line', 'type' => 'text', 'default' => 'Technical support available for engineers, consultants & facility managers'],
                ['name' => 'bg_color', 'label' => '🎨 Section Background Color', 'type' => 'color', 'default' => '#1565c0', 'description' => 'Override the section background color. Leave as default unless rebranding.'],
            ],
        ],

    ],
];
