<?php
/**
 * Axion CMS – Utilities & Substations Page Config
 * Every section and field here is independently editable in the WordPress admin.
 * Default values are served via GraphQL so Next.js never needs hardcoded fallbacks.
 */
if (!defined('ABSPATH')) exit;

return [
    'slug'  => 'utilities-substations',
    'label' => 'Utilities & Substations',
    'sections' => [

        // ═══════════════════════════════════════
        // HERO SECTION
        // ═══════════════════════════════════════
        'hero' => [
            'label' => 'Hero Section',
            'icon'  => '🎯',
            'fields' => [
                ['name' => 'breadcrumb',      'label' => 'Breadcrumb Text',    'type' => 'text',     'default' => 'INDUSTRIES  /  UTILITIES & SUBSTATIONS'],
                ['name' => 'pill',            'label' => 'Pill Badge Text',    'type' => 'text',     'default' => '⚡  UTILITIES & SUBSTATIONS'],
                ['name' => 'heading_line1',   'label' => 'Heading Line 1',     'type' => 'text',     'default' => 'Reliable Battery Systems for'],
                ['name' => 'heading_accent',  'label' => 'Heading Accent',     'type' => 'text',     'default' => 'Utility &'],
                ['name' => 'heading_line2',   'label' => 'Heading Line 2',     'type' => 'text',     'default' => 'Substation Use'],
                ['name' => 'subtitle',        'label' => 'Subtitle',           'type' => 'textarea', 'rows' => 3, 'default' => 'VRLA and flooded battery systems, engineering support, and full lifecycle services for mission-critical DC power.'],
                ['name' => 'btn1_label',      'label' => 'Button 1 Label',     'type' => 'text',     'default' => 'Explore Battery Solutions →'],
                ['name' => 'btn1_url',        'label' => 'Button 1 URL',       'type' => 'text',     'default' => '/contact'],
                ['name' => 'btn2_label',      'label' => 'Button 2 Label',     'type' => 'text',     'default' => 'Talk to an Engineer ↗'],
                ['name' => 'btn2_url',        'label' => 'Button 2 URL',       'type' => 'text',     'default' => '/contact'],
                ['name' => 'image_caption',   'label' => 'Image Caption',      'type' => 'text',     'default' => '📷  Transmission Substation, ON'],
                [
                    'name'         => 'badges',
                    'label'        => 'Hero Badges',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['text' => 'IEEE Compliant'],
                        ['text' => 'VRLA + Flooded'],
                        ['text' => '20+ Years'],
                        ['text' => '24/7 Support'],
                    ],
                    'sub_fields' => [
                        ['name' => 'text', 'label' => 'Badge Text', 'type' => 'text'],
                    ],
                ],
                [
                    'name'         => 'circuit_nodes',
                    'label'        => 'Dashboard Circuit Nodes',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['label' => 'Transmission Bus', 'color' => '#63def7'],
                        ['label' => 'Distribution',     'color' => '#1e88e5'],
                        ['label' => 'Protection Relay', 'color' => '#ffbf45'],
                        ['label' => 'SCADA',            'color' => '#4ade8a'],
                        ['label' => 'Metering',         'color' => '#cc66ff'],
                        ['label' => 'Control House',    'color' => '#1e88e5'],
                    ],
                    'sub_fields' => [
                        ['name' => 'label', 'label' => 'Node Label', 'type' => 'text'],
                        ['name' => 'color', 'label' => 'Node Colour','type' => 'color'],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // APPLICATIONS SECTION
        // ═══════════════════════════════════════
        'applications' => [
            'label' => 'Applications Section',
            'icon'  => '⚡',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'APPLICATIONS'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Powering Every Layer of the Grid'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 3, 'default' => 'From transmission to distribution — Axion delivers proven battery backup for every critical control and protection function.'],
                [
                    'name'         => 'applications',
                    'label'        => 'Application Cards',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['icon' => '🏗️', 'title' => 'Transmission Substations',  'description' => 'High-capacity VRLA and flooded systems for bulk power transfer and protection relay backup.'],
                        ['icon' => '⚡', 'title' => 'Distribution Substations',   'description' => 'Reliable DC backup for feeder protection, sectionalizing, and distribution automation.'],
                        ['icon' => '🖥️', 'title' => 'SCADA & Control Systems',   'description' => 'Uninterrupted power for supervisory control, data acquisition, and remote terminal units.'],
                        ['icon' => '🛡️', 'title' => 'Protection & Relaying',     'description' => 'Mission-critical backup for distance, differential, and overcurrent protection relay panels.'],
                        ['icon' => '📡', 'title' => 'Teleprotection',             'description' => 'Battery backup for communication and teleprotection equipment across transmission corridors.'],
                        ['icon' => '🔌', 'title' => 'Switching & Disconnects',   'description' => 'DC motor drive backup for motorized disconnect switches and circuit breaker trip coils.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon (emoji)', 'type' => 'text'],
                        ['name' => 'title',       'label' => 'Title',        'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description',  'type' => 'textarea', 'rows' => 2],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // BATTERY TECHNOLOGIES SECTION
        // ═══════════════════════════════════════
        'battery-technologies' => [
            'label' => 'Battery Technologies Section',
            'icon'  => '🔋',
            'fields' => [
                ['name' => 'label',        'label' => 'Section Label',     'type' => 'text',     'default' => 'BATTERY TECHNOLOGIES'],
                ['name' => 'heading',      'label' => 'Heading',           'type' => 'text',     'default' => 'The Right Technology for Every Substation'],
                ['name' => 'description',  'label' => 'Description',       'type' => 'textarea', 'rows' => 3, 'default' => 'Axion provides guidance to select the right battery technology based on substation class, maintenance capacity, and IEEE requirements.'],
                ['name' => 'quote',        'label' => 'Pull Quote',        'type' => 'textarea', 'rows' => 2, 'default' => '"The right battery technology makes all the difference."'],
                ['name' => 'image_caption','label' => 'Image Caption',     'type' => 'text',     'default' => '📷  Battery Room — Transmission Substation'],
                [
                    'name'         => 'techs',
                    'label'        => 'Technology Cards',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['icon' => '🔋', 'name' => 'Flooded Lead-Acid', 'subtitle' => 'Vented Wet Cell',        'badge' => 'Long-Life',        'badge_color' => '#ffbf45', 'description' => 'Long design life (15–20+ years) with proper maintenance for Class PS and Class P substations.'],
                        ['icon' => '⚡', 'name' => 'VRLA AGM / GEL',    'subtitle' => 'Valve-Regulated',         'badge' => 'Low Maintenance', 'badge_color' => '#63def7', 'description' => 'Maintenance-free sealed systems for Class SE substations with limited ventilation.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'icon',        'label' => 'Icon (emoji)',    'type' => 'text'],
                        ['name' => 'name',        'label' => 'Technology Name', 'type' => 'text'],
                        ['name' => 'subtitle',    'label' => 'Subtitle',        'type' => 'text'],
                        ['name' => 'badge',       'label' => 'Badge Text',      'type' => 'text'],
                        ['name' => 'badge_color', 'label' => 'Badge Colour',    'type' => 'color'],
                        ['name' => 'description', 'label' => 'Description',     'type' => 'textarea', 'rows' => 2],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // ENGINEERING SUPPORT SECTION
        // ═══════════════════════════════════════
        'engineering-support' => [
            'label' => 'Engineering & Specification Support',
            'icon'  => '🔧',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'ENGINEERING & SPECIFICATION SUPPORT'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Your Technical Partner from Day One.'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 3, 'default' => 'Axion acts as a technical partner throughout the specification and design process — from sizing to installation coordination.'],
                [
                    'name'         => 'steps',
                    'label'        => 'Engineering Steps',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['num' => '01', 'title' => 'IEEE 485 / 1115 Battery Sizing', 'description' => 'Precise Ah calculations per standard methodology for all load and duty profiles.'],
                        ['num' => '02', 'title' => 'Technology Selection',            'description' => 'Flooded vs VRLA recommendation based on substation class and operational needs.'],
                        ['num' => '03', 'title' => 'Charger Coordination',            'description' => 'Matching charger specifications to IEEE 1188 and battery manufacturer requirements.'],
                        ['num' => '04', 'title' => 'Battery Room Design',             'description' => 'Ventilation, containment, thermal management, and safety code compliance.'],
                        ['num' => '05', 'title' => 'Commissioning Support',           'description' => 'Acceptance testing, initial capacity verification, and documentation handover.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'num',         'label' => 'Step Number', 'type' => 'text'],
                        ['name' => 'title',       'label' => 'Title',       'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description', 'type' => 'textarea', 'rows' => 2],
                    ],
                ],
                [
                    'name'         => 'worksheet_rows',
                    'label'        => 'IEEE Sizing Worksheet Rows',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['parameter' => 'Substation Class',  'value' => 'Class P',   'standard' => 'IEEE 485'],
                        ['parameter' => 'Load Current',      'value' => '75 A',      'standard' => ''],
                        ['parameter' => 'Required Runtime',  'value' => '8 hr',      'standard' => ''],
                        ['parameter' => 'Battery Chemistry', 'value' => 'Flooded',   'standard' => ''],
                        ['parameter' => 'System Voltage',    'value' => '125V DC',   'standard' => ''],
                        ['parameter' => 'Calculated Ah',     'value' => '680 Ah',    'standard' => 'RESULT'],
                    ],
                    'sub_fields' => [
                        ['name' => 'parameter', 'label' => 'Parameter',        'type' => 'text'],
                        ['name' => 'value',     'label' => 'Value',            'type' => 'text'],
                        ['name' => 'standard',  'label' => 'Standard / Tag',   'type' => 'text'],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // QUALITY & COMPLIANCE SECTION
        // ═══════════════════════════════════════
        'quality-compliance' => [
            'label' => 'Quality & Compliance Section',
            'icon'  => '🛡️',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'COMPLIANT'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Quality, Safety & Compliance Built Into Every Solution.'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 3, 'default' => 'Utilities require strict adherence to quality, safety, and reliability. Axion partners with trusted manufacturers and follows industry best practices.'],
                [
                    'name'         => 'standards',
                    'label'        => 'Compliance Standards',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['code' => 'IEEE 485',     'title' => 'Battery Sizing',         'description' => 'Recommended Practice for Sizing Lead-Acid Batteries for Stationary Applications.'],
                        ['code' => 'IEEE 1188',    'title' => 'VRLA Maintenance',       'description' => 'Recommended Practice for Maintenance, Testing, and Replacement of VRLA Batteries.'],
                        ['code' => 'IEEE 450',     'title' => 'Flooded Maintenance',    'description' => 'Recommended Practice for Maintenance, Testing, and Replacement of Vented Lead-Acid Batteries.'],
                        ['code' => 'IEC 62133',    'title' => 'Safety Requirements',    'description' => 'Safety requirements for portable sealed secondary lithium cells and batteries.'],
                        ['code' => 'NERC CIP',     'title' => 'Critical Infrastructure','description' => 'Cybersecurity and operational reliability standards for bulk electric systems.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'code',        'label' => 'Standard Code', 'type' => 'text'],
                        ['name' => 'title',       'label' => 'Title',         'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 2],
                    ],
                ],
                [
                    'name'         => 'stats',
                    'label'        => 'Compliance Stats',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['value' => '100%',   'label' => 'Lot Tested'],
                        ['value' => 'IEEE',   'label' => 'Standards Compliant'],
                        ['value' => '<0.01%', 'label' => 'Failure Rate'],
                        ['value' => '20+ yr', 'label' => 'Design Life'],
                    ],
                    'sub_fields' => [
                        ['name' => 'value', 'label' => 'Value', 'type' => 'text'],
                        ['name' => 'label', 'label' => 'Label', 'type' => 'text'],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // LIFECYCLE SUPPORT SECTION
        // ═══════════════════════════════════════
        'lifecycle-support' => [
            'label' => 'Lifecycle Support Section',
            'icon'  => '🔁',
            'fields' => [
                ['name' => 'label',       'label' => 'Section Label', 'type' => 'text',     'default' => 'LIFECYCLE SUPPORT'],
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Support from Commissioning to End-of-Life.'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 3, 'default' => 'Reduces risk, extends service life, and ensures predictable operation over time.'],
                [
                    'name'         => 'phases',
                    'label'        => 'Lifecycle Phases',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['num' => '01', 'icon' => '⚙️',  'title' => 'Commissioning',   'color' => '#63def7', 'description' => 'Initial acceptance testing, baseline capacity recording, and system verification.'],
                        ['num' => '02', 'icon' => '📅',  'title' => 'Annual Testing',  'color' => '#ffbf45', 'description' => 'IEEE 450 / 1188 capacity testing and impedance measurements.'],
                        ['num' => '03', 'icon' => '📊',  'title' => 'Monitoring',      'color' => '#4ade8a', 'description' => 'Remote battery monitoring systems for ongoing health visibility.'],
                        ['num' => '04', 'icon' => '🔄',  'title' => 'Replacement',     'color' => '#cc66ff', 'description' => 'Proactive string replacement and disposal coordination before failures.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'num',         'label' => 'Number',       'type' => 'text'],
                        ['name' => 'icon',        'label' => 'Icon (emoji)', 'type' => 'text'],
                        ['name' => 'title',       'label' => 'Title',        'type' => 'text'],
                        ['name' => 'color',       'label' => 'Circle Colour','type' => 'color'],
                        ['name' => 'description', 'label' => 'Description',  'type' => 'textarea', 'rows' => 2],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // WHY AXION SECTION
        // ═══════════════════════════════════════
        'why-axion' => [
            'label' => 'Why Choose Axion Section',
            'icon'  => '⭐',
            'fields' => [
                ['name' => 'heading',    'label' => 'Heading',    'type' => 'text',     'default' => 'Why utilities choose us, every time.'],
                ['name' => 'subheading', 'label' => 'Subheading', 'type' => 'text',     'default' => 'A long-term technical partnership backed by 20+ years of experience.'],
                ['name' => 'cta_label',  'label' => 'CTA Label',  'type' => 'text',     'default' => 'Get In Touch →'],
                ['name' => 'cta_url',    'label' => 'CTA URL',    'type' => 'text',     'default' => '/contact'],
                [
                    'name'         => 'reasons',
                    'label'        => 'Reasons',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['num' => '01', 'title' => 'IEEE & NERC Compliance Expertise',  'description' => 'Deep understanding of substation standards and compliance requirements.'],
                        ['num' => '02', 'title' => 'Flooded & VRLA Specialists',         'description' => 'Both technologies in-house — right recommendation every time.'],
                        ['num' => '03', 'title' => 'Engineering-Led Sizing',             'description' => 'IEEE 485/1115 calculations with full technical documentation.'],
                        ['num' => '04', 'title' => 'Full Lifecycle Partnership',         'description' => 'From procurement through annual testing to end-of-life disposal.'],
                        ['num' => '05', 'title' => 'Proven in Critical Environments',   'description' => '20+ years serving utilities, co-ops, and independent power producers.'],
                    ],
                    'sub_fields' => [
                        ['name' => 'num',         'label' => 'Number',     'type' => 'text'],
                        ['name' => 'title',       'label' => 'Title',      'type' => 'text'],
                        ['name' => 'description', 'label' => 'Description','type' => 'textarea', 'rows' => 2],
                    ],
                ],
                [
                    'name'         => 'uptime_stats',
                    'label'        => 'Track Record Stats',
                    'type'         => 'repeater',
                    'default_rows' => [
                        ['value' => '99.97%',  'label' => 'System Uptime',      'color' => '#ffbf45'],
                        ['value' => '200+',    'label' => 'Substations Served', 'color' => '#63def7'],
                        ['value' => '3.1M hrs','label' => 'Operating Hours',    'color' => '#4ade8a'],
                        ['value' => '0',       'label' => 'Critical Failures',  'color' => '#cc66ff'],
                    ],
                    'sub_fields' => [
                        ['name' => 'value', 'label' => 'Value',       'type' => 'text'],
                        ['name' => 'label', 'label' => 'Label',       'type' => 'text'],
                        ['name' => 'color', 'label' => 'Accent Colour','type' => 'color'],
                    ],
                ],
            ],
        ],

        // ═══════════════════════════════════════
        // CTA SECTION
        // ═══════════════════════════════════════
        'cta' => [
            'label' => 'CTA Section',
            'icon'  => '📞',
            'fields' => [
                ['name' => 'heading',     'label' => 'Heading',       'type' => 'text',     'default' => 'Design reliable, compliant utility battery systems'],
                ['name' => 'accent_text', 'label' => 'Heading Accent','type' => 'text',     'default' => 'with Axion.'],
                ['name' => 'description', 'label' => 'Description',   'type' => 'textarea', 'rows' => 3, 'default' => 'Contact our team to discuss your project requirements — sizing, selection, compliance, and full lifecycle support.'],
                ['name' => 'btn1_label',  'label' => 'Button 1 Label','type' => 'text',     'default' => 'Contact Axion'],
                ['name' => 'btn1_url',    'label' => 'Button 1 URL',  'type' => 'text',     'default' => '/contact'],
                ['name' => 'btn2_label',  'label' => 'Button 2 Label','type' => 'text',     'default' => 'Request a Specification'],
                ['name' => 'btn2_url',    'label' => 'Button 2 URL',  'type' => 'text',     'default' => '/contact'],
                ['name' => 'btn3_label',  'label' => 'Button 3 Label','type' => 'text',     'default' => 'Download Tech Guide'],
                ['name' => 'btn3_url',    'label' => 'Button 3 URL',  'type' => 'text',     'default' => '/contact'],
            ],
        ],

    ],
];
